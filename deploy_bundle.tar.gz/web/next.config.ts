import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  async rewrites() {
    const apiBase = process.env.INTERNAL_API_URL || "http://localhost:3001";
    return [
      {
        source: "/approvals/:path*",
        destination: `${apiBase}/approvals/:path*`,
      },
      {
        source: "/auth/:path*",
        destination: `${apiBase}/auth/:path*`,
      },
      {
        source: "/batches/:path*",
        destination: `${apiBase}/batches/:path*`,
      },
      {
        source: "/workflows/:path*",
        destination: `${apiBase}/workflows/:path*`,
      },
      {
        source: "/contacts/:path*",
        destination: `${apiBase}/contacts/:path*`,
      },
      {
        source: "/bills/:path*",
        destination: `${apiBase}/bills/:path*`,
      },
      {
        source: "/payments/:path*",
        destination: `${apiBase}/payments/:path*`,
      },
      {
        source: "/notifications/:path*",
        destination: `${apiBase}/notifications/:path*`,
      },
    ];
  },
};

export default nextConfig;
