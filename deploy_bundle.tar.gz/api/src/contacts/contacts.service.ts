import { ConflictException, Injectable, NotFoundException } from '@nestjs/common';
import { BatchStatus } from '@prisma/client';
import { PrismaService } from '../prisma/prisma.service.js';
import { CreateContactDto, UpdateContactDto } from './contact.dto.js';

const contactFields = { id: true, organizationId: true, name: true, email: true, role: true, isActive: true } as const;

@Injectable()
export class ContactsService {
  constructor(private readonly prisma: PrismaService) {}

  listByOrganization(organizationId: string) {
    return this.prisma.contact.findMany({
      where: { organizationId },
      select: contactFields,
      orderBy: { name: 'asc' },
    });
  }

  async create(input: CreateContactDto) {
    const email = input.email.trim().toLowerCase();
    const existing = await this.prisma.contact.findFirst({
      where: { organizationId: input.organizationId, email: { equals: email, mode: 'insensitive' } },
      select: { id: true },
    });
    if (existing) throw new ConflictException('A contact with this email already exists in the organization');

    return this.prisma.contact.create({
      data: {
        organizationId: input.organizationId,
        name: input.name.trim(),
        email,
        role: input.role.trim(),
      },
      select: contactFields,
    });
  }

  async update(id: string, organizationId: string, input: UpdateContactDto) {
    const contact = await this.prisma.contact.findFirst({
      where: { id, organizationId },
      select: { id: true },
    });
    if (!contact) throw new NotFoundException('Contact not found');

    if (input.email) {
      const existing = await this.prisma.contact.findFirst({
        where: { id: { not: id }, organizationId, email: { equals: input.email.trim(), mode: 'insensitive' } },
        select: { id: true },
      });
      if (existing) throw new ConflictException('A contact with this email already exists in the organization');
    }

    const data = {
      ...(input.name !== undefined ? { name: input.name.trim() } : {}),
      ...(input.email !== undefined ? { email: input.email.trim().toLowerCase() } : {}),
      ...(input.role !== undefined ? { role: input.role.trim() } : {}),
      ...(input.isActive !== undefined ? { isActive: input.isActive } : {}),
    };
    if (Object.keys(data).length === 0) throw new ConflictException('Provide at least one contact field to update');

    return this.prisma.contact.update({ where: { id }, data, select: contactFields });
  }

  async delete(id: string, organizationId: string) {
    const contact = await this.prisma.contact.findFirst({
      where: { id, organizationId },
      select: { id: true, name: true },
    });
    if (!contact) throw new NotFoundException('Contact not found');

    // 1. Check if there are any active in-flight bills currently held by this contact
    const activeBatches = await this.prisma.batch.findMany({
      where: {
        template: {
          stages: {
            some: { contactId: id },
          },
        },
        status: { in: [BatchStatus.IN_PROGRESS, BatchStatus.READY_FOR_PAYMENT] },
      },
      select: { id: true },
    });

    if (activeBatches.length > 0) {
      throw new ConflictException(
        `Cannot delete "${contact.name}". There are ${activeBatches.length} active bill(s) in progress using this approver. Settle or cancel those bills first.`,
      );
    }

    // 2. Unlink any backup approver references
    await this.prisma.workflowStage.updateMany({
      where: { backupContactId: id },
      data: { backupContactId: null },
    });

    // 3. For any workflow templates using this contact as primary approver with 0 active batches,
    //    clean up the empty workflow so it doesn't block contact deletion
    const stagesWherePrimary = await this.prisma.workflowStage.findMany({
      where: { contactId: id },
      select: { templateId: true },
    });

    const templateIds = Array.from(new Set(stagesWherePrimary.map((s) => s.templateId)));

    if (templateIds.length > 0) {
      await this.prisma.workflowStage.deleteMany({
        where: { templateId: { in: templateIds } },
      });
      await this.prisma.workflowTemplate.deleteMany({
        where: { id: { in: templateIds } },
      });
    }

    // 4. Permanently delete the contact
    await this.prisma.contact.delete({ where: { id } });
    return { message: `Contact "${contact.name}" deleted permanently`, id };
  }
}
